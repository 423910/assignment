﻿using System;
using System.Linq;
using System.Web.Mvc;
using TwitterCloneApp.Models;

namespace TwitterCloneApp.Controllers
{
    public class HomeController : Controller
    {         
        TWITTERCLONEEntities obj = new TWITTERCLONEEntities();

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Details(TPERSON person)
        {
            var user = obj.TPERSONs.Where(x => x.USERID == person.USERID).FirstOrDefault();
            ViewBag.Message = string.Format("Welcome {0} | Current Date and Time: {1}", user.FULLNAME, DateTime.Now.ToString());
            
            return View(user);
        }

        public ActionResult Change(long id)
        {
            var tweet = obj.TTWEETs.Where(x => x.TWEET_ID == id).FirstOrDefault();
            var user = obj.TPERSONs.Where(x => x.USERID == tweet.USERID).FirstOrDefault();
            ViewBag.Message = string.Format("Welcome {0} | Current Date and Time: {1}", user.FULLNAME, DateTime.Now.ToString());

            return View(tweet);
        }

        [HttpPost]
        public ActionResult Change(TTWEET tweet)
        {
            var user = obj.TPERSONs.Where(x => x.USERID == tweet.USERID).FirstOrDefault();
            ViewBag.Message = string.Format("Welcome {0} | Current Date and Time: {1}", user.FULLNAME, DateTime.Now.ToString());

            obj.Entry(tweet).State = System.Data.Entity.EntityState.Modified;
            obj.SaveChanges();
            return RedirectToAction("Tweet", "Home", user);
        }

        public ActionResult Edit(string id)
        {
            var user = obj.TPERSONs.Where(x => x.USERID == id).FirstOrDefault();
            ViewBag.Message = string.Format("Welcome {0} | Current Date and Time: {1}", user.FULLNAME, DateTime.Now.ToString());
            
            return View(user);
        }

        [HttpPost]
        public ActionResult Edit(TPERSON person)
        {
            ViewBag.Message = string.Format("Welcome {0} | Current Date and Time: {1}", person.FULLNAME, DateTime.Now.ToString());

            obj.Entry(person).State = System.Data.Entity.EntityState.Modified;
            obj.SaveChanges();
            return RedirectToAction("Tweet", "Home", person);
        }

        public ActionResult Delete(long id)
        {
            var tweet = obj.TTWEETs.Where(x => x.TWEET_ID == id).FirstOrDefault();
            var user = obj.TPERSONs.Where(x => x.USERID == tweet.USERID).FirstOrDefault();

            obj.Entry(tweet).State = System.Data.Entity.EntityState.Deleted;
            obj.SaveChanges();

            return RedirectToAction("Tweet", "Home", user);
        }

        public ActionResult Signout()
        {
            return RedirectToAction("Index", "Home");
        }

        public ActionResult Follow(string id, string fid)
        {
            TFOLLOWING follow = new TFOLLOWING
            {
                USERID = id,
                FOLLOWERID = fid
            };
            obj.TFOLLOWINGs.Add(follow);
            obj.SaveChanges();
            var user = obj.TPERSONs.Where(x => x.USERID == id).FirstOrDefault();

            return RedirectToAction("Tweet", "Home", user);
        }

        public ActionResult Search(FormCollection Form)
        {
            var name =  Form["txtFollow"].ToString();
            var userList = obj.TPERSONs.Where(x => x.FULLNAME.Contains(name)).ToList();

            ViewData["UserId"] = Form["UserId"].ToString();
            var user = obj.TPERSONs.Where(x => x.USERID == Form["UserId"].ToString()).FirstOrDefault();
            ViewBag.Message = string.Format("Welcome {0} | Current Date and Time: {1}", user.FULLNAME, DateTime.Now.ToString());

            return View(userList);
        }

        public ActionResult Tweet(TPERSON person)
        {
            ViewBag.Message = string.Format("Welcome {0} | Current Date and Time: {1}", person.FULLNAME, DateTime.Now.ToString());

            ViewData["Person"] = person;

            ViewData["Tweet"] = obj.TTWEETs.Where(x => x.USERID == person.USERID).Count();

            ViewData["Following"] = obj.TFOLLOWINGs.Where(x => x.FOLLOWERID == person.USERID).Count();

            ViewData["Follower"] = obj.TFOLLOWINGs.Where(x => x.USERID == person.USERID).Count();

            var tweetList = obj.TTWEETs.Where(x => x.USERID == person.USERID).ToList();
           
            return View(tweetList);
        }

        [HttpPost]
        public ActionResult Tweet(TTWEET tweet)
        {
            if (tweet != null)
            {
                tweet.CREATED = DateTime.UtcNow;
                obj.TTWEETs.Add(tweet);
                obj.SaveChanges();
            }

            var user = obj.TPERSONs.Where(x => x.USERID == tweet.USERID).FirstOrDefault();

            return RedirectToAction("Tweet", "Home", user);
        }

        [HttpPost]
        public ActionResult Index(TPERSON person)
        {
            var user = obj.TPERSONs.Where(x => x.USERID == person.USERID && x.UPASSWORD == person.UPASSWORD).FirstOrDefault();
            if(user != null)
            {
                return RedirectToAction("Tweet", "Home", user);
            }
            else
            {
                return View();
            }
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(TPERSON person)
        {
            if (person != null)
            {
                person.JOINED = DateTime.Now;
                person.ACTIVE = true;
                obj.TPERSONs.Add(person);
                obj.SaveChanges();
            }

            return RedirectToAction("Index", "Home");
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}