﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace POWebApi
{
    public class PODac
    {
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["PODb"].ConnectionString);

        public List<Item> GetAllItems()
        {
            List<Item> itemList = new List<Item>();
            using (SqlCommand cmd = new SqlCommand("select * from ITEM", conn))
            {
                conn.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                
                while (rdr.Read())
                {
                    Item item = new Item
                    {
                        ItemCode = rdr["ITCODE"].ToString(),
                        ItemDesc = rdr["ITDESC"].ToString(),
                        ItemRate = Convert.ToDecimal(rdr["ITRATE"].ToString())
                    };
                    itemList.Add(item);
                }

                conn.Close();
            }

            return itemList;
        }

        public List<Supplier> GetAllSuppliers()
        {
            List<Supplier> suppList = new List<Supplier>();
            using (SqlCommand cmd = new SqlCommand("select * from SUPPLIER", conn))
            {
                conn.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                
                while (rdr.Read())
                {
                    Supplier supp = new Supplier
                    {
                        SupplierNo = rdr["SUPLNO"].ToString(),
                        SupplierName = rdr["SUPLNAME"].ToString(),
                        SupplierAddress = rdr["SUPLADDR"].ToString()
                    };
                    suppList.Add(supp);
                }
                conn.Close();
            }

            return suppList;
        }

        public List<POMaster> GetAllPOs()
        {
            List<POMaster> poList = new List<POMaster>();
            using (SqlCommand cmd = new SqlCommand("select * from POMASTER", conn))
            {
                conn.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                
                while (rdr.Read())
                {
                    POMaster po = new POMaster
                    {
                        PONumber = rdr["PONO"].ToString(),
                        PODate = Convert.ToDateTime(rdr["PODATE"].ToString()),
                        SupplierNo = rdr["SUPLNO"].ToString()
                    };
                    poList.Add(po);
                }
                conn.Close();
            }

            return poList;
        }

        public List<PODetail> GetAllPODetails()
        {
            List<PODetail> poList = new List<PODetail>();
            using (SqlCommand cmd = new SqlCommand("select * from PODETAIL", conn))
            {
                conn.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                
                while (rdr.Read())
                {
                    PODetail po = new PODetail
                    {
                        PONumber = rdr["PONO"].ToString(),
                        ItemCode = rdr["ITCODE"].ToString(),
                        Quantity = Convert.ToInt32(rdr["QTY"].ToString())
                    };
                    poList.Add(po);
                }
                conn.Close();
            }

            return poList;
        }

        public Item GetItem(string id)
        {
            Item item = null;
            using (SqlCommand cmd = new SqlCommand("select * from ITEM where ITCODE = '" + id +"'", conn))
            {
                conn.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                
                while (rdr.Read())
                {
                    item = new Item
                    {
                        ItemCode = rdr["ITCODE"].ToString(),
                        ItemDesc = rdr["ITDESC"].ToString(),
                        ItemRate = Convert.ToDecimal(rdr["ITRATE"].ToString())
                    };
                }
                conn.Close();
            }

            return item;
        }

        public Supplier GetSupplier(string id)
        {
            Supplier supp = null;
            using (SqlCommand cmd = new SqlCommand("select * from SUPPLIER where SUPLNO = '" + id + "'", conn))
            {
                conn.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                
                while (rdr.Read())
                {
                    supp = new Supplier
                    {
                        SupplierNo = rdr["SUPLNO"].ToString(),
                        SupplierName = rdr["SUPLNAME"].ToString(),
                        SupplierAddress = rdr["SUPLADDR"].ToString()
                    };
                }
                conn.Close();
            }

            return supp;
        }

        public POMaster GetPO(string id)
        {
            POMaster po = null;
            using (SqlCommand cmd = new SqlCommand("select * from POMASTER where PONO = '" + id + "'", conn))
            {
                conn.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                
                while (rdr.Read())
                {
                    po = new POMaster
                    {
                        PONumber = rdr["PONO"].ToString(),
                        PODate = Convert.ToDateTime(rdr["PODATE"].ToString()),
                        SupplierNo = rdr["SUPLNO"].ToString()
                    };
                }
                conn.Close();
            }

            return po;
        }

        public PODetail GetPODetails(string id)
        {
            PODetail po = null;
            using (SqlCommand cmd = new SqlCommand("select * from PODETAIL where PONO = '" + id + "'", conn))
            {
                conn.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                
                while (rdr.Read())
                {
                    po = new PODetail
                    {
                        PONumber = rdr["PONO"].ToString(),
                        ItemCode = rdr["ITCODE"].ToString(),
                        Quantity = Convert.ToInt32(rdr["QTY"].ToString())
                    };
                }
                conn.Close();
            }

            return po;
        }

        public void SaveItem(Item item)
        {
            string sql = "insert into ITEM(ITCODE, ITDESC, ITRATE) values(@ItemCode, @ItemDesc, @ItemRate)";
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@ItemCode", item.ItemCode);
                cmd.Parameters.AddWithValue("@ItemDesc", item.ItemDesc);
                cmd.Parameters.AddWithValue("@ItemRate", item.ItemRate);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }
        }

        public void SaveSupplier(Supplier supp)
        {
            string sql = "insert into SUPPLIER(SUPLNO, SUPLNAME, SUPLADDR) values(@SUPLNO, @SUPLNAME, @SUPLADDR)";
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@SUPLNO", supp.SupplierNo);
                cmd.Parameters.AddWithValue("@SUPLNAME", supp.SupplierName);
                cmd.Parameters.AddWithValue("@SUPLADDR", supp.SupplierAddress);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }
        }

        public void SavePO(POMaster po)
        {
            string sql = "insert into POMASTER(PONO, PODATE, SUPLNO) values(@PONO, @PODATE, @SUPLNO)";
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@PONO", po.PONumber);
                cmd.Parameters.AddWithValue("@PODATE", po.PODate);
                cmd.Parameters.AddWithValue("@SUPLNO", po.SupplierNo);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }
        }

        public void SavePODetail(PODetail po)
        {
            string sql = "insert into PODETAIL(PONO, ITCODE, QTY) values(@PONO, @ITCODE, @QTY)";
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@PONO", po.PONumber);
                cmd.Parameters.AddWithValue("@ITCODE", po.ItemCode);
                cmd.Parameters.AddWithValue("@QTY", po.Quantity);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }
        }

        public void UpdateItem(Item item)
        {
            string sql = "update ITEM set ITDESC=@ItemDesc, ITRATE=@ItemRate where ITCODE=@ItemCode";
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@ItemCode", item.ItemCode);
                cmd.Parameters.AddWithValue("@ItemDesc", item.ItemDesc);
                cmd.Parameters.AddWithValue("@ItemRate", item.ItemRate);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }
        }

        public void UpdateSupplier(Supplier supp)
        {
            string sql = "update SUPPLIER set SUPLNAME = @SUPLNAME, SUPLADDR = @SUPLADDR where SUPLNO=@SUPLNO";
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@SUPLNO", supp.SupplierNo);
                cmd.Parameters.AddWithValue("@SUPLNAME", supp.SupplierName);
                cmd.Parameters.AddWithValue("@SUPLADDR", supp.SupplierAddress);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }
        }

        public void UpdatePO(POMaster po)
        {
            string sql = "update POMASTER set PODATE=@PODATE, SUPLNO=@SUPLNO where PONO=@PONO";
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@PONO", po.PONumber);
                cmd.Parameters.AddWithValue("@PODATE", po.PODate);
                cmd.Parameters.AddWithValue("@SUPLNO", po.SupplierNo);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }
        }

        public void UpdatePODetail(PODetail po)
        {
            string sql = "update PODETAIL set ITCODE = @ITCODE, QTY=@QTY where PONO=@PONO";
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@PONO", po.PONumber);
                cmd.Parameters.AddWithValue("@ITCODE", po.ItemCode);
                cmd.Parameters.AddWithValue("@QTY", po.Quantity);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }
        }

        public void DeleteItem(string id)
        {
            string sql = "delete from ITEM where ITCODE='"+ id +"'";
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }
        }

        public void DeleteSupplier(string id)
        {
            string sql = "delete from SUPPLIER where SUPLNO='"+ id +"'";
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }
        }

        public void DeletePO(string id)
        {
            string sql = "delete from POMASTER where PONO='" + id + "'";
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }
        }

        public void DeletePODetail(string id)
        {
            string sql = "delete from PODETAIL where PONO='"+ id +"'";
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }
        }
    }
}