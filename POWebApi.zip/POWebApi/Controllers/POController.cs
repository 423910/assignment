﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;


namespace POWebApi
{
    public class POController : ApiController
    {
        PODac dac = new PODac();

        [HttpGet]
        [Route("api/po/getallitems")]
        public List<Item> GetAllItems()
        {
            return dac.GetAllItems();
        }

        [HttpGet]
        [Route("api/po/getallsuppliers")]
        public List<Supplier> GetAllSuppliers()
        {
            return dac.GetAllSuppliers();
        }

        [HttpGet]
        [Route("api/po/getallpos")]
        public List<POMaster> GetAllPOs()
        {
            return dac.GetAllPOs();
        }

        [HttpGet]
        [Route("api/po/getallpodetails")]
        public List<PODetail> GetAllPODetails()
        {
            return dac.GetAllPODetails();
        }

        [HttpGet]
        [Route("api/po/getitem")]
        public Item GetItem(string id)
        {
            return dac.GetItem(id);
        }

        [HttpGet]
        [Route("api/po/getsupplier")]
        public Supplier GetSupplier(string id)
        {
            return dac.GetSupplier(id);
        }

        [HttpGet]
        [Route("api/po/getpo")]
        public POMaster GetPO(string id)
        {
            return dac.GetPO(id);
        }

        [HttpGet]
        [Route("api/po/getpodetails")]
        public PODetail GetPODetails(string id)
        {
            return dac.GetPODetails(id);
        }

        [HttpPost]
        [Route("api/po/saveitem")]
        public void SaveItem([FromBody] Item item)
        {
            dac.SaveItem(item);
        }

        [HttpPost]
        [Route("api/po/savesupplier")]
        public void SaveSupplier([FromBody] Supplier supp)
        {
            dac.SaveSupplier(supp);
        }

        [HttpPost]
        [Route("api/po/savepo")]
        public void SavePO([FromBody] POMaster po)
        {
            dac.SavePO(po);
        }

        [HttpPost]
        [Route("api/po/savepodetail")]
        public void SavePODetail([FromBody] PODetail po)
        {
            dac.SavePODetail(po);
        }

        [HttpPost]
        [Route("api/po/updateitem")]
        public void UpdateItem([FromBody] Item item)
        {
            dac.UpdateItem(item);
        }

        [HttpPost]
        [Route("api/po/updatesupplier")]
        public void UpdateSupplier([FromBody] Supplier supp)
        {
            dac.UpdateSupplier(supp);
        }

        [HttpPost]
        [Route("api/po/updatepo")]
        public void UpdatePO([FromBody] POMaster po)
        {
            dac.UpdatePO(po);
        }

        [HttpPost]
        [Route("api/po/updatepodetail")]
        public void UpdatePODetail([FromBody] PODetail po)
        {
            dac.UpdatePODetail(po);
        }

        [HttpPost]
        [Route("api/po/deleteitem")]
        public void DeleteItem([FromBody]string id)
        {
            dac.DeleteItem(id);
        }

        [HttpPost]
        [Route("api/po/deletesupplier")]
        public void DeleteSupplier([FromBody]string id)
        {
            dac.DeleteSupplier(id);
        }

        [HttpPost]
        [Route("api/po/deletepo")]
        public void DeletePO([FromBody]string id)
        {
            dac.DeletePO(id);
        }

        [HttpPost]
        [Route("api/po/deletepodetail")]
        public void DeletePODetail([FromBody]string id)
        {
            dac.DeletePODetail(id);
        }
    }
}