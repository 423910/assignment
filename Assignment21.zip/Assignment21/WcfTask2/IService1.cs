﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace WcfTask2
{
    [ServiceContract]
    public interface IService1
    {
        [OperationContract]
        List<Jobs> OpeningJobs();

        [OperationContract]
        List<Jobs> OpeningJobsByRole(string role);
    }

    [DataContract]
    public class Jobs
    {
        bool isOpen = true;
        string jobTitle = string.Empty;
        long jobId;
        string role = string.Empty;


        [DataMember]
        public bool IsOpen
        {
            get { return isOpen; }
            set { isOpen = value; }
        }

        [DataMember]
        public string JobTitle
        {
            get { return jobTitle; }
            set { jobTitle = value; }
        }

        [DataMember]
        public long JobId
        {
            get { return jobId; }
            set { jobId = value; }
        }

        [DataMember]
        public string Role
        {
            get { return role; }
            set { role = value; }
        }
    }
}
