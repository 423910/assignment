﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace WcfTask2
{
    public class Service1 : IService1
    {
        List<Jobs> jobsList = new List<Jobs>
        {
            new Jobs
            {
                JobId = 1,
                JobTitle = ".Net Developer",
                Role = "Associate",
                IsOpen = true
            },
            new Jobs
            {
                JobId = 2,
                JobTitle = "Java Developer",
                Role = "Associate",
                IsOpen = true
            },
            new Jobs
            {
                JobId = 3,
                JobTitle = ".Net Developer",
                Role = "Sr. Associate",
                IsOpen = true
            },
            new Jobs
            {
                JobId = 4,
                JobTitle = "Java Developer",
                Role = "Sr. Associate",
                IsOpen = true
            },
            new Jobs
            {
                JobId = 5,
                JobTitle = ".Net Developer",
                Role = "Programmer Analyst",
                IsOpen = true
            },
            new Jobs
            {
                JobId = 6,
                JobTitle = "Java Developer",
                Role = "Programmer Analyst",
                IsOpen = true
            }
        };

        public List<Jobs> OpeningJobsByRole(string role)
        {
            var jobByRole = jobsList.Where(x => string.Equals(x.Role, role, StringComparison.OrdinalIgnoreCase)).ToList();
            return jobByRole;
        }

        public List<Jobs> OpeningJobs()
        {
            return jobsList;
        }
    }
}
