﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcApp1.Models
{
    public class Jobs
    {
        bool isOpen = true;
        string jobTitle = string.Empty;
        long jobId;
        string role = string.Empty;

        public bool IsOpen
        {
            get { return isOpen; }
            set { isOpen = value; }
        }

        public string JobTitle
        {
            get { return jobTitle; }
            set { jobTitle = value; }
        }

        public long JobId
        {
            get { return jobId; }
            set { jobId = value; }
        }

        public string Role
        {
            get { return role; }
            set { role = value; }
        }
    }
}