﻿using System;
using System.Collections.Generic;
using System.Web.Mvc;

namespace MvcApp1.Controllers
{
    public class HomeController : Controller
    {
        HttpServiceReference.Service1Client httpClientObj = new HttpServiceReference.Service1Client("BasicHttpBinding_IService1");
        NetTcpServiceReference.Service1Client nettcpClientObj = new NetTcpServiceReference.Service1Client("NetTcpBinding_IService1");
        CalculatorServiceRef.Service1Client calculatorClientObj = new CalculatorServiceRef.Service1Client("BasicHttpBinding_IService12");

        public ActionResult Index()
        {
            if (HttpContext.Request.Form["HttpRequest"] != null)
            {
                ViewBag.Message = "http: " + httpClientObj.SayHello("Divya") + "\n" + httpClientObj.TodayProgram("Divya");
            }
            else if (HttpContext.Request.Form["NetTcpRequest"] != null)
            {
                ViewBag.Message = "netTcp: " + nettcpClientObj.SayHello("Anjali") + "\n" + nettcpClientObj.TodayProgram("Anjali");
            }
            else if(HttpContext.Request.Form["JobOpenings"] != null)
            {
               return RedirectToAction("About", "Home");
            }
            else if(HttpContext.Request.Form["Addition"] != null)
            {
                int val1 = Convert.ToInt32(HttpContext.Request.Form["value1"].ToString());
                int val2 = Convert.ToInt32(HttpContext.Request.Form["value2"].ToString());
                ViewBag.Message = calculatorClientObj.Addition(val1, val2);
            }
            else if(HttpContext.Request.Form["Substraction"] != null)
            {
                int val1 = Convert.ToInt32(HttpContext.Request.Form["value1"].ToString());
                int val2 = Convert.ToInt32(HttpContext.Request.Form["value2"].ToString());
                ViewBag.Message = calculatorClientObj.Substraction(val1, val2);
            }

            return View();
        }

        IISHostedServiceRef.Service1Client iisHostedClientObj = new IISHostedServiceRef.Service1Client("BasicHttpBinding_IService11");
        public ActionResult About()
        {
            var jobs = iisHostedClientObj.OpeningJobs();
            List<Models.Jobs> openJobs = new List<Models.Jobs>();
            foreach (var job in jobs)
            {
                openJobs.Add(new Models.Jobs
                {
                    JobId = job.JobId,
                    JobTitle = job.JobTitle,
                    Role = job.Role
                });
            }

            if (HttpContext.Request.Form["Associate"] != null)
            {
                openJobs = openJobs.FindAll(x => x.Role == "Associate");
            }
            else if (HttpContext.Request.Form["SrAssociate"] != null)
            {
                openJobs = openJobs.FindAll(x => x.Role == "Sr. Associate");
            }
            else if (HttpContext.Request.Form["ProgrammerAnalyst"] != null)
            {
                openJobs = openJobs.FindAll(x => x.Role == "Programmer Analyst");
            }

            return View(openJobs);
        }
    }
}