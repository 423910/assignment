﻿using System.ServiceModel;

namespace WcfSvc1
{
    [ServiceContract]
    public interface IService1
    {
        [OperationContract]
        string SayHello(string name);

        [OperationContract]
        string TodayProgram(string time);
    }
}
