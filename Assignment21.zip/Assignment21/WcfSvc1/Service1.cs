﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace WcfSvc1
{
    public class Service1 : IService1
    {
        public string SayHello(string value)
        {
            var message = string.Empty;
            var time = DateTime.Now.Hour;
            if (time > 5 && time < 12)
            {
                message = "Good Morning! ";
            }
            else if (time > 12 && time < 16)
            {
                message = "Good Afternoon! ";
            }
            else if (time > 16 && time < 19)
            {
                message = "Good Evening! ";
            }
            else if (time > 19 && time < 20)
            {
                message = "Good Night! ";
            }
            return message + value;
        }

        public string TodayProgram(string value)
        {
            var message = string.Empty;
            var today = DateTime.Today.DayOfWeek;

            if (today == DayOfWeek.Saturday || today == DayOfWeek.Sunday)
            {
                message = "Happy weekend! ";
            }
            else
            {
                message = "Enjoy Working day! ";
            }

            return message + value;
        }
    }
}
