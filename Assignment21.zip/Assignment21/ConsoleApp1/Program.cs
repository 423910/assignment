using System;
using System.ServiceModel;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            ServiceHost host = new ServiceHost(typeof(WcfSvc1.Service1));
            if (host != null)
            {
                host.Open();
                Console.WriteLine("Service Started............");
                Console.ReadLine();
                host.Close();
            }
        }
    }
}
