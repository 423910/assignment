﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace POMvcApp
{
    public class POController : Controller
    {
        string Baseurl = "http://localhost:62371/api/po/";

        #region Retrieve

        public async Task<ActionResult> RetrieveItem()
        {
            List<Item> ItemInfo = new List<Item>();

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Baseurl);

                client.DefaultRequestHeaders.Clear();

                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                HttpResponseMessage Res = await client.GetAsync("getallitems");

                if (Res.IsSuccessStatusCode)
                {
                    var ItemResponse = Res.Content.ReadAsStringAsync().Result;

                    ItemInfo = JsonConvert.DeserializeObject<List<Item>>(ItemResponse);
                }
                return View(ItemInfo);
            }
        }

        public async Task<ActionResult> RetrieveSupplier()
        {
            List<Supplier> SuppInfo = new List<Supplier>();

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Baseurl);

                client.DefaultRequestHeaders.Clear();

                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                HttpResponseMessage Res = await client.GetAsync("getallsuppliers");

                if (Res.IsSuccessStatusCode)
                {
                    var SuppResponse = Res.Content.ReadAsStringAsync().Result;

                    SuppInfo = JsonConvert.DeserializeObject<List<Supplier>>(SuppResponse);
                }
                return View(SuppInfo);
            }
        }

        public async Task<ActionResult> RetrievePO()
        {
            List<POMaster> POInfo = new List<POMaster>();

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Baseurl);

                client.DefaultRequestHeaders.Clear();

                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                HttpResponseMessage Res = await client.GetAsync("getallpos");

                if (Res.IsSuccessStatusCode)
                {
                    var POResponse = Res.Content.ReadAsStringAsync().Result;

                    POInfo = JsonConvert.DeserializeObject<List<POMaster>>(POResponse);
                }
                return View(POInfo);
            }
        }

        public async Task<ActionResult> RetrievePODetail()
        {
            List<PODetail> POInfo = new List<PODetail>();

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Baseurl);

                client.DefaultRequestHeaders.Clear();

                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                HttpResponseMessage Res = await client.GetAsync("getallpodetails");

                if (Res.IsSuccessStatusCode)
                {
                    var POResponse = Res.Content.ReadAsStringAsync().Result;

                    POInfo = JsonConvert.DeserializeObject<List<PODetail>>(POResponse);
                }
                return View(POInfo);
            }
        }

        #endregion

        #region Save

        public ActionResult SaveItem()
        {
            return View();
        }

        [HttpPost]
        public ActionResult SaveItem(Item item)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Baseurl);

                client.DefaultRequestHeaders.Clear();

                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                //HTTP POST
                var postTask = client.PostAsJsonAsync<Item>("saveitem", item);

                var result = postTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    return RedirectToAction("RetrieveItem", "PO");
                }
            }

            ModelState.AddModelError(string.Empty, "Server Error. Please contact administrator.");

            return View(item);
        }

        public ActionResult SaveSupplier()
        {
            return View();
        }

        [HttpPost]
        public ActionResult SaveSupplier(Supplier supp)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Baseurl);

                client.DefaultRequestHeaders.Clear();

                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                //HTTP POST
                var postTask = client.PostAsJsonAsync<Supplier>("savesupplier", supp);

                var result = postTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    return RedirectToAction("RetrieveSupplier", "PO");
                }
            }

            ModelState.AddModelError(string.Empty, "Server Error. Please contact administrator.");

            return View(supp);
        }

        public ActionResult SavePO()
        {
            return View();
        }

        [HttpPost]
        public ActionResult SavePO(POMaster po)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Baseurl);

                client.DefaultRequestHeaders.Clear();

                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                //HTTP POST
                var postTask = client.PostAsJsonAsync<POMaster>("savepo", po);

                var result = postTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    return RedirectToAction("RetrievePO", "PO");
                }
            }

            ModelState.AddModelError(string.Empty, "Server Error. Please contact administrator.");

            return View(po);
        }

        public ActionResult SavePODetail()
        {
            return View();
        }

        [HttpPost]
        public ActionResult SavePODetail(PODetail po)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Baseurl);

                client.DefaultRequestHeaders.Clear();

                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                //HTTP POST
                var postTask = client.PostAsJsonAsync<PODetail>("savepodetail", po);

                var result = postTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    return RedirectToAction("RetrievePODetail", "PO");
                }
            }

            ModelState.AddModelError(string.Empty, "Server Error. Please contact administrator.");

            return View(po);
        }
        #endregion

        #region Update

        public async Task<ActionResult> UpdateItem(string id)
        {
            Item ItemInfo = new Item();

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Baseurl);

                client.DefaultRequestHeaders.Clear();

                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                HttpResponseMessage Res = await client.GetAsync(string.Format("getitem?id={0}", id));
            
                if (Res.IsSuccessStatusCode)
                {
                    var ItemResponse = Res.Content.ReadAsStringAsync().Result;

                    ItemInfo = JsonConvert.DeserializeObject<Item>(ItemResponse);
                }
                return View(ItemInfo);
            }
        }

        [HttpPost]
        public ActionResult UpdateItem(Item item)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Baseurl);

                client.DefaultRequestHeaders.Clear();

                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                //HTTP POST
                var postTask = client.PostAsJsonAsync<Item>("updateitem", item);

                var result = postTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    return RedirectToAction("RetrieveItem", "PO");
                }
            }

            ModelState.AddModelError(string.Empty, "Server Error. Please contact administrator.");

            return View(item);
        }

        public async Task<ActionResult> UpdateSupplier(string id)
        {
            Supplier SuppInfo = new Supplier();

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Baseurl);

                client.DefaultRequestHeaders.Clear();

                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                HttpResponseMessage Res = await client.GetAsync(string.Format("getsupplier?id={0}", id));

                if (Res.IsSuccessStatusCode)
                {
                    var SuppResponse = Res.Content.ReadAsStringAsync().Result;

                    SuppInfo = JsonConvert.DeserializeObject<Supplier>(SuppResponse);
                }
                return View(SuppInfo);
            }
        }

        [HttpPost]
        public ActionResult UpdateSupplier(Supplier supp)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Baseurl);

                client.DefaultRequestHeaders.Clear();

                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                //HTTP POST
                var postTask = client.PostAsJsonAsync<Supplier>("updatesupplier", supp);

                var result = postTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    return RedirectToAction("RetrieveSupplier", "PO");
                }
            }

            ModelState.AddModelError(string.Empty, "Server Error. Please contact administrator.");

            return View(supp);
        }

        public async Task<ActionResult> UpdatePO(string id)
        {
            POMaster POInfo = new POMaster();

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Baseurl);

                client.DefaultRequestHeaders.Clear();

                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                HttpResponseMessage Res = await client.GetAsync(string.Format("getpo?id={0}", id));

                if (Res.IsSuccessStatusCode)
                {
                    var POResponse = Res.Content.ReadAsStringAsync().Result;

                    POInfo = JsonConvert.DeserializeObject<POMaster>(POResponse);
                }
                return View(POInfo);
            }
        }

        [HttpPost]
        public ActionResult UpdatePO(POMaster po)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Baseurl);

                client.DefaultRequestHeaders.Clear();

                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                //HTTP POST
                var postTask = client.PostAsJsonAsync<POMaster>("updatepo", po);

                var result = postTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    return RedirectToAction("RetrievePO", "PO");
                }
            }

            ModelState.AddModelError(string.Empty, "Server Error. Please contact administrator.");

            return View(po);
        }

        public async Task<ActionResult> UpdatePODetail(string id)
        {
            PODetail POInfo = new PODetail();

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Baseurl);

                client.DefaultRequestHeaders.Clear();

                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                HttpResponseMessage Res = await client.GetAsync(string.Format("getpodetails?id={0}", id));

                if (Res.IsSuccessStatusCode)
                {
                    var POResponse = Res.Content.ReadAsStringAsync().Result;

                    POInfo = JsonConvert.DeserializeObject<PODetail>(POResponse);
                }
                return View(POInfo);
            }
        }

        [HttpPost]
        public ActionResult UpdatePODetail(PODetail po)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Baseurl);

                client.DefaultRequestHeaders.Clear();

                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                //HTTP POST
                var postTask = client.PostAsJsonAsync<PODetail>("updatepodetail", po);

                var result = postTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    return RedirectToAction("RetrievePODetail", "PO");
                }
            }

            ModelState.AddModelError(string.Empty, "Server Error. Please contact administrator.");

            return View(po);
        }

        #endregion

        #region Delete

        public ActionResult DeleteItem(string id)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Baseurl);

                client.DefaultRequestHeaders.Clear();

                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                //HTTP POST
                var postTask = client.PostAsJsonAsync<string>("deleteitem", id);

                var result = postTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    return RedirectToAction("RetrieveItem", "PO");
                }
            }

            ModelState.AddModelError(string.Empty, "Server Error. Please contact administrator.");

            return RedirectToAction("RetrieveItem", "PO");
        }

        public ActionResult DeleteSupplier(string id)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Baseurl);

                client.DefaultRequestHeaders.Clear();

                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                //HTTP POST
                var postTask = client.PostAsJsonAsync<string>("deletesupplier", id);

                var result = postTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    return RedirectToAction("RetrieveSupplier", "PO");
                }
            }

            ModelState.AddModelError(string.Empty, "Server Error. Please contact administrator.");

            return RedirectToAction("RetrieveSupplier", "PO");
        }

        public ActionResult DeletePO(string id)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Baseurl);

                client.DefaultRequestHeaders.Clear();

                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                //HTTP POST
                var postTask = client.PostAsJsonAsync<string>("deletepo", id);

                var result = postTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    return RedirectToAction("RetrievePO", "PO");
                }
            }

            ModelState.AddModelError(string.Empty, "Server Error. Please contact administrator.");

            return RedirectToAction("RetrievePO", "PO");
        }

        public ActionResult DeletePODetail(string id)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Baseurl);

                client.DefaultRequestHeaders.Clear();

                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                //HTTP POST
                var postTask = client.PostAsJsonAsync<string>("deletepodetail", id);

                var result = postTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    return RedirectToAction("RetrievePODetail", "PO");
                }
            }

            ModelState.AddModelError(string.Empty, "Server Error. Please contact administrator.");

            return RedirectToAction("RetrievePODetail", "PO");
        }

        #endregion
    }
}