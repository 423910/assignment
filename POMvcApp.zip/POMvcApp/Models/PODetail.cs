﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace POMvcApp
{
    public class PODetail
    {
        public string PONumber { get; set; }
        public string ItemCode { get; set; }
        public int Quantity { get; set; }
    }
}