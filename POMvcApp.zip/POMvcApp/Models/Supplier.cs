﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace POMvcApp
{
    public class Supplier
    {
        public string SupplierNo { get; set; }
        public string SupplierName { get; set; }
        public string SupplierAddress { get; set; }
    }
}