﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace POMvcApp
{
    public class POMaster
    {
        public string PONumber { get; set; }
        public DateTime PODate { get; set; }
        public string SupplierNo { get; set; }
    }
}